<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
 * 
 * For 
 * @package     Site
 * @subpackage  Base Extended
 * @category    Registration
 * @author      Techffodils Technologies LLP
 * @link        https://techffodils.com
 */
class Promotion_model extends CI_Model {
    
}
