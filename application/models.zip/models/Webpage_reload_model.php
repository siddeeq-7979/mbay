<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
 * 
 * For 
 * @package     Site
 * @subpackage  Base Extended
 * @category    Registration
 * @author      Techffodils Technologies LLP
 * @link        https://techffodils.com
 */
class Webpage_reload_model extends CI_model {

}
