<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/**
 * 
 * 
 * For general related models
 * @package     Site
 * @subpackage  Base Extended
 * @category    general
 * @author      Techffodils Technologies LLP
 * @link        https://techffodils.com
 */
class General_model extends CI_Model {
    
}
