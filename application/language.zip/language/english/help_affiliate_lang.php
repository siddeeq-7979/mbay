<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
$lang['menu_help_4'] = 'For each affiliates, there is a profile in the system to see their own profile. It’s highly professional and manageable';
$lang['menu_help_126'] = 'For Add new Inquiry';
$lang['menu_help_127'] = 'For View the affiliate inquiry';
$lang['menu_help_46'] = 'View News- Option for administrator for seeing the published news and all other inactive news';
$lang['menu_help_154']='Option for seeing the published news as a timeline';
$lang['menu_help_155']='Option for seeing the published events';
$lang['menu_help_108'] = 'Shows the added events as Calendar';
