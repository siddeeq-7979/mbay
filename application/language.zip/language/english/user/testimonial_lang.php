<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
$lang['create_testinomial'] = 'Create Testimonial';
$lang['success'] = 'Testimonial Created Successfully';
$lang['content'] = 'Content';
$lang['content_msg'] = 'Please enter Content';
$lang['content_msg_length'] = 'Please enter 10 characters';
$lang['title_msg'] = 'Please enter Title';
