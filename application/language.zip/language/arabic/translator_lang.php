<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
$lang['translator'] ='مترجم';
$lang['select_from_lang'] ='اختر من اللغة';
$lang['from_lang'] ='من اللغة';
$lang['select_to_lang'] ='اختر للغة';
$lang['to_lang'] ='للغة';
$lang['content'] ='يحتوى';
$lang['result'] ='نتيجة';
$lang['translate'] ='ترجمه';
$lang['please_enter_all_required_fields'] ='الرجاء إدخال جميع الحقول المطلوبة';
$lang['something_went_wrong_pls_try_again'] ='حدث خطأ ما. أعد المحاولة من فضلك';
$lang['from_lang_req_js'] ='من اللغة مطلوب';
$lang['to_lang_req_js'] ='إلى اللغة مطلوب';
$lang['content_req_js'] ='المحتوى مطلوب';
$lang['pls_wait_js'] ='أرجو الإنتظار...';
$lang['same_source_target'] ='عذرًا ، المصدر والهدف مماثلان';

