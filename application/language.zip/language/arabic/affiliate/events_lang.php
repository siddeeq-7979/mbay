<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
$lang['event_name'] ='اسم الحدث';
$lang['event_desc'] ='وصف الحدث';
$lang['single_day'] ='يوم واحد';
$lang['multiple_day'] ='يوم متعددة';
$lang['calendar'] ='التقويم';
$lang['select_from_date'] ='اختر من التاريخ';
$lang['select_to_date'] ='اختر حتى الآن';
$lang['event_type'] ='نوع الحدث';
$lang['event_date'] ='تاريخ الحدث';

