<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
$lang['add_kyc_details'] ='أضف تفاصيل KYC';
$lang['form_error_messages'] ='لديك بعض أخطاء النماذج. يرجى مراجعة أدناه.';
$lang['form_success_messages'] ='التحقق من صحة النموذج الخاص بك ناجح!';
$lang['bank_details'] ='التفاصيل المصرفية';
$lang['id_proof'] ='تفاصيل إثبات الهوية';
$lang['bank_account_no'] ='رقم الحساب المصرفي';
$lang['upload_proof'] ='تحميل دليل البنك';
$lang['bank_ifc_code'] ='رمز IFC / SWIFT';
$lang['name_as_per_proof'] ='اسم حسب البروفة';
$lang['id_number'] ='رقم الهوية';
$lang['please_select_allowcd_iamges'] ='يرجى اختيار الصور';
$lang['please_select_allocated_iamges'] ='يرجى تحديد الصور المخصصة jpeg / png / gif';
$lang['successfully_upload_kyc_details'] ='تم بنجاح تحميل KYC التفاصيل';
$lang['error_upload_kyc_details'] ='حدث خطأ أثناء تحميل Kyc Details';

