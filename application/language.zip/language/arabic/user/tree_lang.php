<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
$lang['genealogy_tree'] ='شجرة الأنساب';
$lang['sponsor_tree'] ='شجرة الراعي';
$lang['root_tree'] ='شجرة الجذر';
$lang['empty_tree'] ='شجرة فارغة ، لا يوجد Downlines المتاحة';
$lang['email'] ='البريد الإلكتروني';
$lang['join_date'] ='تاريخ الانضمام';
$lang['tabular_tree'] ='شجرة أفقية';
$lang['user_name'] ='اسم المستخدم';
$lang['lives_in'] ='يعيش أيضا في';
$lang['downlines'] ='داونلينيس';
$lang['left_user_count'] ='المستخدم ترك يسار';
$lang['right_user_count'] ='المستخدم حق كاري';
$lang['user_total_left'] ='العضو إجمالي اليسار';
$lang['user_total_right'] ='العضو إجمالي الحق';
$lang['search_member'] ='ابحث عن عضو';

