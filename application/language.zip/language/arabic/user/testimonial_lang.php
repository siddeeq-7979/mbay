<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
$lang['create_testinomial'] ='خلق شهادة';
$lang['success'] ='Testimonial Created Successfully';
$lang['content'] ='يحتوى';
$lang['content_msg'] ='يرجى إدخال المحتوى';
$lang['content_msg_length'] ='يرجى إدخال 10 أحرف';
$lang['title_msg'] ='يرجى إدخال العنوان';

