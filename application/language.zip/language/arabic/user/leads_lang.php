<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
$lang['leads'] ='يؤدي';
$lang['first_name'] ='الاسم الاول';
$lang['last_name'] ='الكنية';
$lang['email'] ='عنوان البريد الإلكتروني';
$lang['phone_no'] ='رقم الهاتف';
$lang['country'] ='بلد';
$lang['comment'] ='تعليق';
$lang['date'] ='تاريخ';
$lang['no_leads'] ='لا يؤدي المتاحة';

