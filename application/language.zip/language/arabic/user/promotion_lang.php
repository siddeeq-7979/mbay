<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
$lang['promotion'] ='ترقية وظيفية';
$lang['replication_link'] ='رابط النسخ المتماثل';
$lang['copy_link'] ='انسخ الرابط';
$lang['lcp_link'] ='صفحة التقاط الرصاص';
$lang['referal_link'] ='رابط الإحالة';
$lang['copied_js'] ='رابط نسخ بنجاح';
$lang['succ_js'] ='نجاح';

