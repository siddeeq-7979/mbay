<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
$lang['promotion'] = 'Promotion';
$lang['replication_link'] = 'Replication Link';
$lang['copy_link'] = 'Copy link';
$lang['lcp_link'] = 'Lead Capture Page';
$lang['referal_link'] = 'Referal Link';
$lang['copied_js'] = 'Link Copied Successfully';
$lang['succ_js'] = 'Success';
